import React from 'react';
import {View,Text,Image,StyleSheet} from 'react-native';
import Card from './Card';
import CardItem from './CardItem';

export default class AlbumDetail extends React.Component{
   
    render(){
        return (<View>
           <Card>
               <CardItem>
                   <View style={styles.thumbnailContainerStyle}>
                       <Image
                       style={styles.thumbnailStyle}
                       source={{uri:this.props.details.thumbnail_image}}
                        ></Image>
                   </View>
                   <View style={styles.headerContentStyle}>
                       <Text style={styles.headerTextStyle}>{this.props.details.title}</Text>
                       <Text>{this.props.details.artist}</Text>
                   </View>
               </CardItem>
           </Card>
           <CardItem>
               <Image
               style={styles.ImageStyle}
                source={{uri:this.props.details.image}}
               ></Image>
           </CardItem>
        
        <CardItem>
            {/* Add a button here ! */}
        </CardItem>
        
        </View>);
    }
}

const styles = StyleSheet.create({
    headerContentStyle:{
        flexDirection:'column',
        justifyContent:'space-around'
    },
    headerTextStyle:{
        height:40,
        width:50
    },
    thumbnailContainerStyle:{
        justifyContent:'center',
        alignItems:'center',
        marginLeft:10,
        marginRight:10
    },
    ImageStyle:{
        height:300,
        flex:1,
        width:null
    },
    thumbnailStyle:{
        height:50,
        width:50
    }

})