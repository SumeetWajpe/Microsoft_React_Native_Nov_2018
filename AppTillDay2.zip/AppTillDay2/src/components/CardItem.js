import React from 'react';
import {View,Text,StyleSheet} from 'react-native';

export default class CardItem extends React.Component{
    render(){
      return  <View style={styles.containerStyle}>
            {this.props.children}
        </View>
    }
}

const styles = StyleSheet.create({
    containerStyle:{
        padding:5,       
        borderBottomWidth:1,
        backgroundColor:'#FFF',
        flexDirection:'row',
        justifyContent:'flex-start'
        
    }
})