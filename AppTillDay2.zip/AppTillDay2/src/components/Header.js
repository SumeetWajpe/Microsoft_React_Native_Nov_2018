import React from 'react';
import {Text,View,StyleSheet} from 'react-native';



// Functional Component or stateless 
const Header = (props) =>{
    const {viewStyle,headerTextStyle} = styles;
    return <View style={viewStyle}>
                    <Text style={headerTextStyle}> {props.message} </Text>
                </View> 
                }
const styles = StyleSheet.create({
    headerTextStyle:{        
        fontSize:20
    },
    viewStyle:{
        backgroundColor:'#F6F6F6',
        justifyContent:'center',
        alignItems:'center',
        height:60,
        paddingTop:10,
        shadowColor:'#000',
        shadowOffset:{width:0,height:4},
        shadowOpacity:0.8,
        elevation:2,
        position:'relative'
    }
})


export default Header;