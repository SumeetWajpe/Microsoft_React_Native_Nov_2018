import React from 'react';
import {View,ScrollView} from 'react-native';
import AlbumDetail from './AlbumDetail';
import axios from 'axios';

export default class AlbumList extends React.Component{
    
    constructor(props){
        super(props);
        this.state = {albums:[]};
    }

    componentDidMount() {
        axios.get('https://api.myjson.com/bins/lods6')
          .then(response => this.setState({ albums: response.data }));
      }

    render(){

        var itemsToBeCreated = this.state.albums.map(
            album => <AlbumDetail key={album.title} 
            details={album} />
        )

      return ( <ScrollView>
            {/* Use Album Detail Here ! */}
           {itemsToBeCreated}
        </ScrollView>);
    }
}